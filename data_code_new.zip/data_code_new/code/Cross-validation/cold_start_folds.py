import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error


def temporal_cold_start_folds(df, k=5, min_train_frac=0.5, cold_col="item_id"):
    """
    df 需要包含: user_id, item_id, target, ts
    返回每个 fold:
      train_idx / test_idx        : 相对 df 的 iloc 下标
      test_seen_mask              : 测试样本的 cold_col 在训练集出现过
      test_unseen_mask            : 测试样本的 cold_col 未在训练集出现，即冷启动样本
    """
    df = df.sort_values("ts").reset_index(drop=True)
    n = len(df)
    start = int(n * min_train_frac)
    cuts = np.linspace(start, n, k + 1).astype(int)

    for i in range(k):
        train_idx = np.arange(0, cuts[i])
        test_idx = np.arange(cuts[i], cuts[i + 1])

        if len(train_idx) == 0 or len(test_idx) == 0:
            continue

        train_cold_values = set(df.iloc[train_idx][cold_col])
        seen_mask = df.iloc[test_idx][cold_col].isin(train_cold_values).to_numpy()

        yield {
            "fold": i,
            "train_idx": train_idx,
            "test_idx": test_idx,
            "test_seen_mask": seen_mask,
            "test_unseen_mask": ~seen_mask,
        }


def cold_start_cv(model, df, k=5, min_train_frac=0.5, cold_col="item_id"):
    rows = []

    for sp in temporal_cold_start_folds(df, k=k, min_train_frac=min_train_frac, cold_col=cold_col):
        tr = df.iloc[sp["train_idx"]]
        te = df.iloc[sp["test_idx"]]

        # TODO: 这里改成你的特征构造；若特征依赖全局统计量，必须在 train 内 fit，避免泄漏
        X_tr = tr[["user_id", "item_id"]]
        X_te = te[["user_id", "item_id"]]

        model.fit(X_tr, tr["target"])
        pred = model.predict(X_te)
        y = te["target"].to_numpy()

        def mae(mask):
            return mean_absolute_error(y[mask], pred[mask]) if mask.any() else np.nan

        rows.append({
            "fold": sp["fold"],
            "n_test": len(te),
            "n_unseen": int(sp["test_unseen_mask"].sum()),
            "mae_all": mean_absolute_error(y, pred),
            "mae_seen": mae(sp["test_seen_mask"]),
            "mae_cold_unseen": mae(sp["test_unseen_mask"]),
        })

    return pd.DataFrame(rows)


# 示例：
# result = cold_start_cv(model, df, k=5, min_train_frac=0.5, cold_col="item_id")
# print(result)
# print(result[["mae_all", "mae_seen", "mae_cold_unseen"]].mean())