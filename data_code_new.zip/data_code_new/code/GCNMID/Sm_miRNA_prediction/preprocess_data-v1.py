"""
Preprocess SMILES + miRNA sequences for GCNMID/GCNNMMA-style models.

Input data.txt format (whitespace-separated, one pair per line):
    <SMILES> <miRNA sequence> <label>

Outputs:
    Smiles.txt                 kept SMILES, one per line
    compounds.npy              list of np.array, atom/subgraph fingerprint IDs
    adjacencies.npy            list of np.array, adjacency matrices (with H)
    proteins.npy               list of np.array, n-gram word IDs
    interactions.npy           list of np.array([label])
    fingerprint_dict.pickle    subgraph fingerprint -> ID
    word_dict.pickle           n-gram word -> ID

Note: .npy files store lists of variable-length arrays as object arrays;
load them with np.load(path, allow_pickle=True).
"""

import argparse
import os
import pickle
import sys
from collections import defaultdict

import numpy as np
from rdkit import Chem


class GraphPreprocessor:
    def __init__(self, radius, ngram):
        self.radius = int(radius)
        self.ngram = int(ngram)

        self.atom_dict = defaultdict(lambda: len(self.atom_dict))
        self.bond_dict = defaultdict(lambda: len(self.bond_dict))
        self.fingerprint_dict = defaultdict(lambda: len(self.fingerprint_dict))
        self.edge_dict = defaultdict(lambda: len(self.edge_dict))
        self.word_dict = defaultdict(lambda: len(self.word_dict))

    # ---------- small molecule ----------
    def create_atoms(self, mol):
        """Atom IDs, distinguishing aromatic atoms."""
        atoms = [a.GetSymbol() for a in mol.GetAtoms()]
        for a in mol.GetAromaticAtoms():
            i = a.GetIdx()
            atoms[i] = (atoms[i], 'aromatic')
        return np.array([self.atom_dict[a] for a in atoms])

    def create_ijbonddict(self, mol):
        """Adjacency dict: atom index -> [(neighbor index, bond ID), ...]."""
        i_jbond_dict = defaultdict(list)
        for b in mol.GetBonds():
            i, j = b.GetBeginAtomIdx(), b.GetEndAtomIdx()
            bond = self.bond_dict[str(b.GetBondType())]
            i_jbond_dict[i].append((j, bond))
            i_jbond_dict[j].append((i, bond))
        return i_jbond_dict

    def extract_fingerprints(self, atoms, i_jbond_dict):
        """r-radius subgraph fingerprints via Weisfeiler-Lehman updates."""
        if len(atoms) == 1 or self.radius == 0:
            return np.array([self.fingerprint_dict[a] for a in atoms])

        nodes = list(atoms)
        i_jedge_dict = i_jbond_dict

        for _ in range(self.radius):
            fingerprints = [None] * len(nodes)
            for i in range(len(nodes)):
                j_edge = i_jedge_dict.get(i, [])
                neighbors = [(nodes[j], edge) for j, edge in j_edge]
                fingerprint = (nodes[i], tuple(sorted(neighbors)))
                fingerprints[i] = self.fingerprint_dict[fingerprint]

            _i_jedge_dict = defaultdict(list)
            for i, j_edge in i_jedge_dict.items():
                for j, edge in j_edge:
                    both_side = tuple(sorted((fingerprints[i], fingerprints[j])))
                    new_edge = self.edge_dict[(both_side, edge)]
                    _i_jedge_dict[i].append((j, new_edge))

            nodes = fingerprints
            i_jedge_dict = _i_jedge_dict

        return np.array(fingerprints)

    def create_adjacency(self, mol):
        return np.array(Chem.GetAdjacencyMatrix(mol))

    # ---------- miRNA sequence ----------
    def split_sequence(self, sequence):
        """Pad with '-' and '=' then split into overlapping n-grams."""
        sequence = '-' + sequence + '='
        words = [
            self.word_dict[sequence[i:i + self.ngram]]
            for i in range(len(sequence) - self.ngram + 1)
        ]
        return np.array(words)

    # ---------- main ----------
    def process(self, data_path, out_dir):
        with open(data_path, 'r') as f:
            raw_lines = [line.strip() for line in f if line.strip()]

        valid_lines, skipped = [], 0
        for line in raw_lines:
            parts = line.split()
            if len(parts) < 3:
                skipped += 1
                continue
            smiles = parts[0]
            # Exclude multi-fragment SMILES (containing '.')
            if '.' in smiles:
                skipped += 1
                continue
            valid_lines.append(line)

        N = len(valid_lines)
        print(f'Total valid lines: {N}, skipped: {skipped}')

        smiles_list = []
        compounds, adjacencies, proteins, interactions = [], [], [], []

        for no, line in enumerate(valid_lines, start=1):
            if no % 100 == 0 or no == N:
                print(f'{no}/{N}')

            parts = line.split()
            smiles, sequence, interaction = parts[0], parts[1], parts[2]

            mol = Chem.MolFromSmiles(smiles)
            if mol is None:
                print(f'[Warning] Failed to parse SMILES: {smiles}', file=sys.stderr)
                continue
            mol = Chem.AddHs(mol)

            atoms = self.create_atoms(mol)
            i_jbond_dict = self.create_ijbonddict(mol)
            fingerprints = self.extract_fingerprints(atoms, i_jbond_dict)
            compounds.append(fingerprints)

            adjacencies.append(self.create_adjacency(mol))
            proteins.append(self.split_sequence(sequence))
            interactions.append(np.array([float(interaction)]))
            smiles_list.append(smiles)

        os.makedirs(out_dir, exist_ok=True)

        with open(os.path.join(out_dir, 'Smiles.txt'), 'w') as f:
            f.write('\n'.join(smiles_list) + '\n')

        np.save(os.path.join(out_dir, 'compounds.npy'), compounds, allow_pickle=True)
        np.save(os.path.join(out_dir, 'adjacencies.npy'), adjacencies, allow_pickle=True)
        np.save(os.path.join(out_dir, 'proteins.npy'), proteins, allow_pickle=True)
        np.save(os.path.join(out_dir, 'interactions.npy'), interactions, allow_pickle=True)

        with open(os.path.join(out_dir, 'fingerprint_dict.pickle'), 'wb') as f:
            pickle.dump(dict(self.fingerprint_dict), f)
        with open(os.path.join(out_dir, 'word_dict.pickle'), 'wb') as f:
            pickle.dump(dict(self.word_dict), f)

        print(f'Preprocessing finished. Outputs written to: {out_dir}')
        print(f'  compounds: {len(compounds)}, adjacencies: {len(adjacencies)}, '
              f'proteins: {len(proteins)}, interactions: {len(interactions)}')
        print(f'  fingerprint_dict size: {len(self.fingerprint_dict)}, '
              f'word_dict size: {len(self.word_dict)}')


def parse_args():
    parser = argparse.ArgumentParser(
        description='Preprocess SMILES + miRNA sequences for GCNMID.'
    )
    parser.add_argument('dataset', help='Dataset name, e.g. SM2miR1')
    parser.add_argument('radius', type=int, help='Subgraph radius r')
    parser.add_argument('ngram', type=int, help='n-gram size for miRNA sequence')
    parser.add_argument('--data-root', default='../dataset',
                        help='Root directory containing <dataset>/original/data.txt')
    parser.add_argument('--out-root', default=None,
                        help='Output root; default: <data-root>/<dataset>/input/'
                             'radius<r>_ngram<n>/')
    return parser.parse_args()


def main():
    args = parse_args()

    data_path = os.path.join(args.data_root, args.dataset, 'original', 'data.txt')
    if args.out_root is None:
        out_dir = os.path.join(
            args.data_root, args.dataset, 'input',
            f'radius{args.radius}_ngram{args.ngram}'
        )
    else:
        out_dir = args.out_root

    if not os.path.isfile(data_path):
        raise FileNotFoundError(f'Input file not found: {data_path}')

    preprocessor = GraphPreprocessor(radius=args.radius, ngram=args.ngram)
    preprocessor.process(data_path, out_dir)


if __name__ == '__main__':
    main()