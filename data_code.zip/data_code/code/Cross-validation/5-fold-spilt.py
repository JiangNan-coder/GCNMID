import numpy as np
from sklearn.model_selection import KFold
def five_fold_split_with_twnsf(positive_pairs, all_candidate_pairs, twnsf_func, n_splits=5, seed=42):
    """
    五折划分，每一折的负样本由 TWNSF 仅基于训练正样本筛选。
    """
    positive_pairs = np.array(positive_pairs)
    all_candidate_pairs = np.array(all_candidate_pairs)

    kf = KFold(n_splits=n_splits, shuffle=True, random_state=seed)
    folds = []

    for tr_idx, te_idx in kf.split(positive_pairs):
        train_pos = positive_pairs[tr_idx]
        test_pos = positive_pairs[te_idx]

        # 候选负样本 = 所有候选对 - 训练正样本 - 测试正样本
        train_pos_set = set(map(tuple, train_pos))
        test_pos_set = set(map(tuple, test_pos))
        candidates = [
            p for p in map(tuple, all_candidate_pairs)
            if p not in train_pos_set and p not in test_pos_set
        ]

        # TWNSF 仅使用训练正样本筛选负样本
        train_neg = twnsf_func(train_pos, candidates)

        folds.append({
            'train_pos': train_pos,
            'train_neg': np.array(train_neg),
            'test_pos': test_pos,
        })
    return folds
