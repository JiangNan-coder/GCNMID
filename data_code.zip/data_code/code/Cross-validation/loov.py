import numpy as np

def loocv_positive(positive_pairs, candidate_pairs, neg_sampler, random_seed=42):
    """
    正样本留一交叉验证（LOOCV）。

    参数:
        positive_pairs: list or np.ndarray, 已知正样本对, 例如 [(sm_i, mir_j), ...]
        candidate_pairs: list or np.ndarray, 所有候选对（用于筛选负样本）
        neg_sampler: callable, 负样本筛选函数, 输入 (train_pos, candidates), 返回负样本列表
        random_seed: int, 随机种子（如负采样需要）

    返回:
        folds: list of dict, 每一折包含:
            'train_pos', 'train_neg', 'test_pos'
    """
    positive_pairs = [tuple(p) for p in positive_pairs]
    candidate_pairs = [tuple(p) for p in candidate_pairs]
    candidate_set = set(candidate_pairs)

    folds = []
    for i, test_pos in enumerate(positive_pairs):
        train_pos = [p for j, p in enumerate(positive_pairs) if j != i]

        train_pos_set = set(train_pos)
        test_pos_set = {test_pos}

        # 候选负样本 = 候选对 - 训练正样本 - 测试正样本
        neg_candidates = [
            p for p in candidate_pairs
            if p not in train_pos_set and p not in test_pos_set
        ]

        # 仅基于训练正样本筛选负样本
        train_neg = neg_sampler(train_pos, neg_candidates)

        folds.append({
            'train_pos': np.array(train_pos),
            'train_neg': np.array(train_neg),
            'test_pos': np.array([test_pos]),
        })
    return folds


# ---------- 示例：随机负采样 ----------
def random_neg_sampler(train_pos, neg_candidates, ratio=1.0, seed=42):
    rng = np.random.default_rng(seed)
    n_neg = int(len(train_pos) * ratio)
    n_neg = min(n_neg, len(neg_candidates))
    idx = rng.choice(len(neg_candidates), size=n_neg, replace=False)
    return [neg_candidates[i] for i in idx]


if __name__ == "__main__":
    # 示例正样本
    positive_pairs = [(i, j) for i in range(20) for j in range(5)][:50]

    # 示例候选对（全部可能的小分子–miRNA 对）
    all_sm = list(range(30))
    all_mir = list(range(10))
    candidate_pairs = [(i, j) for i in all_sm for j in all_mir]

    folds = loocv_positive(
        positive_pairs,
        candidate_pairs,
        neg_sampler=random_neg_sampler,
        random_seed=42
    )

    print(f"Total folds: {len(folds)}")
    for k, fold in enumerate(folds[:3], 1):
        print(f"Fold {k}:")
        print("  Train pos:", len(fold['train_pos']))
        print("  Train neg:", len(fold['train_neg']))
        print("  Test  pos:", len(fold['test_pos']))
