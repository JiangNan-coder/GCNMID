import numpy as np

def leave_one_drug_out(positive_pairs, candidate_pairs, neg_sampler):
    """
    留一药物交叉验证（leave-one-drug-out）。

    参数:
        positive_pairs: list or np.ndarray, 正样本对, 例如 [(sm_i, mir_j), ...]
        candidate_pairs: list or np.ndarray, 所有候选对
        neg_sampler: callable, 负样本筛选函数, 输入 (train_pos, neg_candidates), 返回负样本列表

    返回:
        folds: list of dict, 每一折包含:
            'test_drug', 'train_pos', 'train_neg', 'test_pos'
    """
    positive_pairs = [tuple(p) for p in positive_pairs]
    candidate_pairs = [tuple(p) for p in candidate_pairs]

    # 所有出现过的药物（小分子）
    all_drugs = sorted(set(p[0] for p in positive_pairs))

    folds = []
    for test_drug in all_drugs:
        # 涉及该药物的正样本作为测试集
        test_pos = [p for p in positive_pairs if p[0] == test_drug]
        # 其余正样本作为训练集
        train_pos = [p for p in positive_pairs if p[0] != test_drug]

        train_pos_set = set(train_pos)
        test_pos_set = set(test_pos)

        # 候选负样本 = 候选对 - 训练正样本 - 测试正样本
        neg_candidates = [
            p for p in candidate_pairs
            if p not in train_pos_set and p not in test_pos_set
        ]

        # 仅基于训练正样本筛选负样本
        train_neg = neg_sampler(train_pos, neg_candidates)

        folds.append({
            'test_drug': test_drug,
            'train_pos': np.array(train_pos),
            'train_neg': np.array(train_neg),
            'test_pos': np.array(test_pos),
        })
    return folds


# ---------- 示例：随机负采样 ----------
def random_neg_sampler(train_pos, neg_candidates, ratio=1.0, seed=42):
    rng = np.random.default_rng(seed)
    n_neg = int(len(train_pos) * ratio)
    n_neg = min(n_neg, len(neg_candidates))
    idx = rng.choice(len(neg_candidates), size=n_neg, replace=False)
    return [neg_candidates[i] for i in idx]


if __name__ == "__main__":
    # 示例正样本
    positive_pairs = [
        (0, 0), (0, 1), (1, 0), (1, 2), (2, 1),
        (2, 3), (3, 2), (3, 4), (4, 3), (4, 4),
    ]

    # 示例候选对
    all_sm = list(range(10))
    all_mir = list(range(5))
    candidate_pairs = [(i, j) for i in all_sm for j in all_mir]

    folds = leave_one_drug_out(
        positive_pairs,
        candidate_pairs,
        neg_sampler=random_neg_sampler
    )

    print(f"Total folds: {len(folds)}")
    for k, fold in enumerate(folds, 1):
        print(f"Fold {k} (test drug = {fold['test_drug']}):")
        print("  Train pos:", len(fold['train_pos']))
        print("  Train neg:", len(fold['train_neg']))
        print("  Test  pos:", len(fold['test_pos']))
