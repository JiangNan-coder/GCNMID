import numpy as np

def twnsf(Sm, Ss, B, beta=0.7, n_neg=None):
    """
    Trustworthy Negative Sample Filtering (TWNSF)

    参数:
        Sm : np.ndarray, shape (n_mirna, n_mirna)
             miRNA 相似度矩阵
        Ss : np.ndarray, shape (n_sm, n_sm)
             小分子药物相似度矩阵
        B  : np.ndarray, shape (n_sm, n_mirna)
             小分子–miRNA 关联矩阵, 1 表示已知关联, 0 表示未知
        beta : float
             平衡指数项和对数项的权重, 默认 0.7
        n_neg : int or None
             需要选出的可信负样本数量; 若为 None, 则选与正样本相同数量

    返回:
        twnsf_pairs : list of tuple
            选出的可信负样本 (sm_idx, mir_idx)
        alpha : np.ndarray, shape (n_sm, n_mirna)
            每个候选对的 TWNSF 分数
    """
    n_sm, n_mir = B.shape

    # 候选负样本: B == 0 的位置
    candidate_mask = (B == 0)
    candidate_idx = np.argwhere(candidate_mask)  # shape (M, 2)

    alpha = np.full((n_sm, n_mir), -np.inf, dtype=np.float64)

    for sm_j, mir_k in candidate_idx:
        # ---------- Step 1: 小分子侧相似度加权 ----------
        # 已知与 mir_k 关联的小分子
        known_sm = np.where(B[:, mir_k] == 1)[0]
        if len(known_sm) > 0:
            SmMiR_jk = np.sum(Ss[sm_j, known_sm])
        else:
            SmMiR_jk = 0.0

        # ---------- Step 2: miRNA 侧相似度加权 ----------
        # 已知与 sm_j 关联的 miRNA
        known_mir = np.where(B[sm_j, :] == 1)[0]
        if len(known_mir) > 0:
            MiRSm_kj = np.sum(Sm[mir_k, known_mir])
        else:
            MiRSm_kj = 0.0

        # ---------- Step 3: 计算 alpha ----------
        s = SmMiR_jk + MiRSm_kj
        # 避免 log(0)
        log_term = np.log(s) if s > 0 else 0.0
        alpha[sm_j, mir_k] = beta * np.exp(-s) + (1 - beta) * log_term

    # ---------- 排序并选出可信负样本 ----------
    # 论文中: alpha 越大, 越可能是可信负样本
    flat_scores = alpha[candidate_mask]
    sorted_order = np.argsort(-flat_scores)  # 降序

    if n_neg is None:
        n_neg = int(np.sum(B == 1))  # 与正样本 1:1

    n_neg = min(n_neg, len(sorted_order))
    selected_flat_idx = sorted_order[:n_neg]
    selected_pairs = candidate_idx[selected_flat_idx]

    twnsf_pairs = [tuple(p) for p in selected_pairs]
    return twnsf_pairs, alpha


# ---------- 使用示例 ----------
if __name__ == "__main__":
    np.random.seed(42)

    n_sm, n_mir = 20, 10
    Sm = np.random.rand(n_mir, n_mir)
    Sm = (Sm + Sm.T) / 2
    np.fill_diagonal(Sm, 1.0)

    Ss = np.random.rand(n_sm, n_sm)
    Ss = (Ss + Ss.T) / 2
    np.fill_diagonal(Ss, 1.0)

    B = np.zeros((n_sm, n_mir), dtype=int)
    # 随机设置一些已知关联
    for _ in range(30):
        i = np.random.randint(n_sm)
        j = np.random.randint(n_mir)
        B[i, j] = 1

    twnsf_pairs, alpha = twnsf(Sm, Ss, B, beta=0.7)

    print("Number of selected trustworthy negatives:", len(twnsf_pairs))
    print("First 10 selected pairs:", twnsf_pairs[:10])
