import numpy as np


def nmf_lncrna_mirna(Y, r, max_iter=1000, tol=1e-6,
                     random_state=42, eps=1e-10, verbose=False):
    """
    标准 NMF，用于 lncRNA-miRNA 相互作用预测。

    目标函数:
        min_{U,V>=0} ||Y - U^T V||_F^2

    更新规则:
        u_ki <- u_ki * (V Y^T)_ki / (V V^T U)_ki
        v_kj <- v_kj * (U Y)_kj / (U U^T V)_kj

    参数:
        Y: 非负矩阵, 形状 (l, m)
           l = lncRNA 个数, m = miRNA 个数
        r: 潜在因子个数
        max_iter: 最大迭代次数
        tol: 收敛容差
        random_state: 随机种子
        eps: 防止除零的小常数

    返回:
        U: 形状 (r, l)
        V: 形状 (r, m)
        errors: 每次迭代的重构误差列表
    """
    rng = np.random.default_rng(random_state)
    l, m = Y.shape

    # 随机非负初始化
    U = rng.random((r, l))
    V = rng.random((r, m))

    errors = []
    prev_error = np.inf

    for it in range(max_iter):
        # ---- 更新 U ----
        # u_ki <- u_ki * (V Y^T)_ki / (V V^T U)_ki
        numerator_U = V @ Y.T              # (r, m) @ (m, l) -> (r, l)
        denominator_U = V @ V.T @ U        # (r, r) @ (r, l) -> (r, l)
        U = U * numerator_U / (denominator_U + eps)

        # ---- 更新 V ----
        # v_kj <- v_kj * (U Y)_kj / (U U^T V)_kj
        numerator_V = U @ Y                # (r, l) @ (l, m) -> (r, m)
        denominator_V = U @ U.T @ V        # (r, r) @ (r, m) -> (r, m)
        V = V * numerator_V / (denominator_V + eps)

        # ---- 计算重构误差 ----
        Y_hat = U.T @ V
        error = np.linalg.norm(Y - Y_hat, ord='fro')
        errors.append(error)

        if verbose and (it % 100 == 0 or it == max_iter - 1):
            print(f"Iter {it:4d}, error = {error:.6e}")

        # ---- 判断收敛 ----
        if abs(prev_error - error) < tol:
            if verbose:
                print(f"Converged at iteration {it}, error = {error:.6e}")
            break

        prev_error = error

    return U, V, errors


# =========================
# 示例
# =========================
if __name__ == "__main__":
    # 假设 5 个 lncRNA, 6 个 miRNA
    Y = np.array([
        [1, 0, 1, 0, 0, 1],
        [0, 1, 0, 1, 1, 0],
        [1, 1, 0, 0, 1, 0],
        [0, 0, 1, 1, 0, 1],
        [1, 0, 0, 1, 0, 1],
    ], dtype=float)

    r = 2   # 潜在因子个数

    U, V, errors = nmf_lncrna_mirna(
        Y, r,
        max_iter=1000,
        tol=1e-6,
        random_state=42,
        verbose=True
    )

    print("\nU shape:", U.shape)   # (r, l)
    print("V shape:", V.shape)     # (r, m)

    # 预测得分矩阵：U^T V
    score = U.T @ V
    print("\nPredicted interaction score matrix (U^T V):")
    print(np.round(score, 4))

    # 重构误差
    print("\nFinal reconstruction error:",
          np.linalg.norm(Y - score, ord='fro'))
